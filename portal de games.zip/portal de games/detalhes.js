let params = new URLSearchParams(window.location.search);
let gameID = params.get("id");
const key = "9085211cf5434cd380dee02c7be6b221";

let names = document.getElementById("gameName");
let ratings = document.getElementById("gameRating");
let images = document.getElementById("gameIMG");
let release = document.getElementById("gameRelease");
let dev = document.getElementById("gameCreator");
let description = document.getElementById("gameInfo") ;

let yet = document.getElementById("yet");
let owned = document.getElementById("owned");
let beaten = document.getElementById("beaten");
let toplay = document.getElementById("toplay");
let dropped = document.getElementById("dropped");
let playing = document.getElementById("playing");

let reddit = document.getElementById("reddit");

let urlSearch = "https://api.rawg.io/api/games/" + gameID + "?key=" + key;

fetch(urlSearch)
    .then(res => res.json())
    .then(data => {
        console.log(data);
        names.innerHTML = data.name;
        ratings.innerHTML = "⭐" + data.rating + '/' + data.rating_top;
        dev.innerHTML = data.developers[0].name;
        images.innerHTML = "<img class=p-6 src=" + data.background_image + "></img>";
        release.innerHTML = data.released;

        description.innerHTML = data.description;

        yet.innerHTML = "⚪ Desejados: " +  data.added_by_status?.yet;
        owned.innerHTML = "📂 Guardados: " + data.added_by_status?.owned;
        beaten.innerHTML = "🟢 Zerados: "+ data.added_by_status?.beaten;
        toplay.innerHTML =  "💛 Favoritados: " +  data.added_by_status?.toplay;
        dropped.innerHTML =  "🔴 Dropados: " + data.added_by_status?.dropped;
        playing.innerHTML = "🎮 Jogando: " +  data.added_by_status?.playing;

        reddit.innerHTML = "<a href=" + data.reddit_url + ">Reddit</a>";  
    })