let params = new URLSearchParams(window.location.search);
let gameName = params.get("name");
const key = "9085211cf5434cd380dee02c7be6b221";

let searchResults = document.getElementById("searchResults");
searchResults = '';

let urlSearch = "https://api.rawg.io/api/games?key=" + key + "&search=" + gameName + "&page_size=4";

let names = document.getElementsByClassName("gameName");
let ratings = document.getElementsByClassName("ratings");
let images = document.getElementsByClassName("gameIMG");
let playtime = document.getElementsByClassName("playtime");
let info0 = document.getElementsByClassName("info0");
let info1 = document.getElementsByClassName("info1");
let ids = []

fetch(urlSearch)
    .then(res => res.json())
    .then(data => {


        
        for (let c = 0; c<names.length; c++){



            names[c].innerHTML = data.results[c].name;
            ratings[c].innerHTML = "⭐" + data.results[c].rating + "/" + data.results[c].rating_top;
            images[c].innerHTML =  "<img src=" + data.results[c].background_image + "></img>";

            playtime[c].innerHTML = data.results[c].playtime + " horas";

            info0[c].innerHTML = 
            "⚪ Lista de desejos: " + data.results[c].added_by_status?.yet + "<br>" + 
            "🟢 Zerados: " + data.results[c].added_by_status?.beaten + "<br>" + 
            "🔴 Dropados: " + data.results[c].added_by_status?.dropped + "<br>" ;

            info1[c].innerHTML =
            "💛 Favoritados: " + data.results[c].added_by_status?.toplay + "<br>" + 
            "🎮 Jogando: " + data.results[c].added_by_status?.playing + "<br>";

            ids.push(data.results[c].id)

        }

    }).then(data=>{
        document.getElementById("choise0").addEventListener("click", () => goTo(0));
        document.getElementById("choise1").addEventListener("click", () => goTo(1));
        document.getElementById("choise2").addEventListener("click", () => goTo(2));
        document.getElementById("choise3").addEventListener("click", () => goTo(3));
    
        function goTo(num){
            let urlGoTo = "detalhes.html?id=" + ids[num];
            window.location.href = urlGoTo;;
        }
    })




