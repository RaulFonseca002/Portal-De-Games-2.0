const key = "9085211cf5434cd380dee02c7be6b221"

const frontpage0 = "celeste";
const frontpage1 = "katana zero";
const frontpage2 = "terraria";



const urlGames = "https://api.rawg.io/api/games?key=" + key + "&search=" + frontpage0 + "%" + frontpage1 + "%" + frontpage2;
let names = document.getElementsByClassName("gameName");
let ratings = document.getElementsByClassName("ratings");
let images = document.getElementsByClassName("gameIMG");
let playtime = document.getElementsByClassName("playtime");
let info = document.getElementsByClassName("info");

let ids = [];

fetch(urlGames)
    .then(res => res.json())
    .then(data => {
        for (let c = 0; c<names.length; c++){

            names[c].innerHTML = data.results[c].name;
            ratings[c].innerHTML = "⭐" + data.results[c].rating + "/" + data.results[c].rating_top;
            images[c].innerHTML =  "<img src=" + data.results[c].background_image + "></img>";

            playtime[c].innerHTML = data.results[c].playtime + " horas";

            info[c].innerHTML = 
            "⚪ Lista de desejos: " + data.results[c].added_by_status?.yet + "<br>" + 
            "🟢 Zerados: "+data.results[c].added_by_status?.beaten + "<br>" + 
            "🔴 Dropados" + data.results[c].added_by_status?.dropped + "<br>" + 
            "💛 Favoritados: " + data.results[c].added_by_status?.toplay + "<br>" + 
            "🎮 Jogando agora: " + data.results[c].added_by_status?.playing + "<br>";

            ids.push(data.results[c].id)
        }
        
})

    let publisherIMG = document.getElementsByClassName("publisherIMG");
    let publisherName = document.getElementsByClassName("publisherName");
    let GamesCount = document.getElementsByClassName("GamesCount");
    const urlPublishers = "https://api.rawg.io/api/publishers?key=" + key;

    fetch(urlPublishers)
    .then(res => res.json())
    .then(data => {
        for (let c = 0; c<publisherName.length; c++){
            publisherIMG[c].innerHTML = "<img "+"class=object-contain src=" + data.results[c].image_background + "></img>" ;
            publisherName[c].innerHTML = data.results[c].name;
            GamesCount[c].innerHTML = "Games count: "+data.results[c].games_count;
        }
    }).then(data => {
        document.getElementById("frontGame0").addEventListener("click", () => goTo(0));
        document.getElementById("frontGame1").addEventListener("click", () => goTo(1));
        document.getElementById("frontGame2").addEventListener("click", () => goTo(2));

        function goTo(num){
            let urlGoTo = "detalhes.html?id=" + ids[num];
            window.location.href = urlGoTo;
}
    })


function searchEngine(){
    var searchName = document.getElementById("inputSearch").value;

    let urlGoTo = "pesquisa.html?name=" + searchName;
    window.location.href = urlGoTo;

}

document.getElementById("inputSearchButton").addEventListener("click", searchEngine);
document.getElementById("inputSearch").addEventListener("submit", searchEngine);

